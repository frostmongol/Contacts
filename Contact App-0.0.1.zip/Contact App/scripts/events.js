$(document).ready(function() {
    $("#newItem").click(function(){
        $("#inputForm").slideToggle();
    })
})